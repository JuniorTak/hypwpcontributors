=== Hyp Contributors ===

Contributors:      Hyppolite T.
Tested up to:      6.7
Stable tag:        1.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html
Tags:              contributors, post, metabox, postmeta

Hyp Contributors is a plugin to add contributors to blog posts of your websites.

== Description ==

Hyp Slideshow allows users to add blog posts contributors from registered users. While editing a post, user can select contributors using a metabox and then when saving the post, all selected contributors are saved as post meta data.

== Installation ==

1. Download the [plugin .zip file](https://github.com/JuniorTak/hypwpcontributors/raw/main/hypcontributors.1.0.0.zip)
2. In the site dashboard, visit **Plugins**.
3. Click **Add New Plugin**, then click **Upload Plugin**.
3. Click **Choose File** and load the plugin .zip file you just downloaded, then click **Install Now**.
4. Once the installation is complete, activate the Hyp Slideshow plugin.

== Usage ==

1. In the site dashboard, visit **Users**, and add some WordPress users.
2. Add a new post or edit an existing one.
3. From the post settings in the editor side panel, scroll down to **Contributors** section.
4. Check usernames to add post contributors.
5. Click **Publish** or **Update** when you finish.
6. In the front-side of your WordPress site, visit the post to see the contributors box right below the post content.

== Frequently Asked Questions ==

= Where can I contribute to the plugin? =

All development for this plugin is handled via [GitHub](https://github.com/JuniorTak/hyp4rtslideshow/) any issues or pull requests should be posted there.


== Changelog ==

= 1.0.0 =
* Add - Initial release.
* Feature - Overhaul of the main plugin and design.
